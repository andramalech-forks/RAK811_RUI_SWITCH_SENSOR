#ifndef __APP_PRODUCT_H_
#define __APP_PRODUCT_H_


#define BME680
#define BATTERY
#define RAK7204


#endif
