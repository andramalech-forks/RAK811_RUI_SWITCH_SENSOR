#ifndef __APP_PRODUCT_H_
#define __APP_PRODUCT_H_


#define BATTERY
#define RAK7204


#endif
